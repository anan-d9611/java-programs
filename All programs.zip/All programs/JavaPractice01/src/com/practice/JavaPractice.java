package com.practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JavaPractice {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver loaded");
		String url="jdbc:mysql://localhost:3306/student";
		String user="root";
		String pwd="";
		Connection con=DriverManager.getConnection(url,user, null);
		System.out.println("Connection Established");
		Statement st = con.createStatement();
		/*String sql1= "create table Student(roll int, name varchar(20),mobile long)";
		st.execute(sql1);
		System.out.println("Table Created");
		String sql2 = "insert into Student values (1,'Ramesh',1111111111)";
		int row = st.executeUpdate(sql2);
		System.out.println(row + "rows inserted");*/
		
		String sql3 = "insert into student values (2,'Kamlesh',2222222222)";
	}

}
