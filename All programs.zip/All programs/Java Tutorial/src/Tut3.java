
public class Tut3 {

	public static void main(String[] args) {
		
        int n = 25;
        
        for (int i=1; i<=25; i++) {
        	if (i%2==0)
        	System.out.println(i);
        }
        }


	}
