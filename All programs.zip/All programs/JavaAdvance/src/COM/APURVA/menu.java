package COM.APURVA;

import java.sql.*;
import java.util.Scanner;
public class menu {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // Load MySQL Driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Drivers Loaded");
        // Database credentials
        String url = "jdbc:mysql://localhost:3306/java001";
        String user = "root";
        String pwd = "";
        // Establish connection
        Connection con = DriverManager.getConnection(url, user, pwd);
        System.out.println("Connection Established");
        Scanner sc = new Scanner(System.in);
        int choice;
     
        while (true) {
            System.out.println("\nWhat Operation Do You Want To Perform?");
            System.out.println("1: Add Data");
            System.out.println("2: Display Data");
            System.out.println("3: Delete Data");
            System.out.println("4: Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    String sqlInsert = "INSERT INTO student VALUES (?,?,?,?,?)";
                    PreparedStatement ps = con.prepareStatement(sqlInsert);
                    System.out.print("How many records do you want to insert? ");
                    int len = sc.nextInt();
                    for (int i = 1; i <= len; i++) {
                        System.out.println("Enter details for record " + i + ":");
                        System.out.print("Roll No: ");
                        int roll = sc.nextInt();
                        System.out.print("Name: ");
                        String name = sc.next();
                        System.out.print("Mobile: ");
                        long mobile = sc.nextLong();
                        System.out.print("Age: ");
                        int age = sc.nextInt();
                        System.out.print("City: ");
                        String city = sc.next();
                        ps.setInt(1, roll);
                        ps.setString(2, name);
                        ps.setLong(3, mobile);
                        ps.setInt(4, age);
                        ps.setString(5, city);

                        ps.executeUpdate();
                        System.out.println("Record " + i + " Inserted Successfully");
                    }
                    break;
                case 2:
                    String sqlSelect = "SELECT * FROM student";
                    Statement st = con.createStatement();
                    ResultSet rs = st.executeQuery(sqlSelect);
                    System.out.println("\nRoll\tName\tMobile\t\tAge\tCity");
                    System.out.println("------------------------------------------------");
                    while (rs.next()) {
                        int roll = rs.getInt("roll");
                        String name = rs.getString("name");
                        long mobile = rs.getLong("mobile");
                        int age = rs.getInt("age");
                        String city = rs.getString("city");
                        System.out.println(roll + "\t" + name + "\t" + mobile + "\t" + age + "\t" + city);
                    }
                    break;
                case 3:
                    System.out.print("Enter Roll No to delete: ");
                    int delRoll = sc.nextInt();
                    String sqlDelete = "DELETE FROM student WHERE roll=?";
                    PreparedStatement psDelete = con.prepareStatement(sqlDelete);
                    psDelete.setInt(1, delRoll);
                    int deletedRows = psDelete.executeUpdate();
                    if (deletedRows > 0) {
                        System.out.println("Record Deleted Successfully!");
                    } else {
                        System.out.println("No record found with Roll No: " + delRoll);
                    }
                    break;
                case 4:
                    System.out.println("Exiting the program...");
                    sc.close();
                    con.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
