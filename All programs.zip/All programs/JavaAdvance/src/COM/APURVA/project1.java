package COM.APURVA;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class project1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver Loaded");
		String url="jdbc:mysql://localhost:3306/java001";
		String user="root";
		String pwd="";
		Connection con=DriverManager.getConnection(url,user, null);
		System.out.println("Connection Established");
		Statement st = con.createStatement();
		String sql;
		//String sql = "create table Student(roll int, name varchar(20),mobile long)";
		//st.execute(sql);
		//System.out.println("Table Created");
		//String sql1 = "insert into Student values (1,'Rahul',1111111111)";
		//int row = st.executeUpdate(sql1);
		//System.out.println(row + "rows inserted");
		/*
		 String sql = "insert into student values (?,?,?)";
		 
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("How many record do you want to insert ");
		int len = sc.nextInt();
		
		for(int i=1;i<=len;i++) {
			System.out.println("Enter " + i +" Rollno.");
			int roll = sc.nextInt();
			System.out.println("Enter "+ i +" Name");
			String name = sc.next();
			System.out.println("Enter" + i +" Mobile");
			long mobile = sc.nextLong();
			
			pstmt.setInt(1, roll);
			pstmt.setString(2, name);
			pstmt.setLong(3, mobile);
			
			int row=pstmt.executeUpdate();
			
		    System.out.println(+i+"Record Inserted");
		}
		    */
		    
		PreparedStatement pstmt;
		sql = "select * from Student";
		pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		
        while(rs.next()) {
			
			int roll = rs.getInt("roll");
			String name = rs.getString("name");
			long mobile = rs.getLong("mobile");
			System.out.println(roll + "\t\t" + name + "\t\t" + mobile );
		}
        
		System.out.println("Enter roll number to be deleted: ");
		Scanner sc = new Scanner(System.in);
		int del_roll = sc.nextInt();
		sql="delete from student where roll = " + del_roll;
		pstmt = con.prepareStatement(sql);
		pstmt.execute();
		System.out.println("Record Deleted");
		
		sql = "select * from Student";
		pstmt = con.prepareStatement(sql);
	    rs = pstmt.executeQuery();
	    
while(rs.next()) {
			
			int roll = rs.getInt("roll");
			String name = rs.getString("name");
			long mobile = rs.getLong("mobile");
			System.out.println(roll + "\t\t" + name + "\t\t" + mobile );
		}      
		
	}
	
}

