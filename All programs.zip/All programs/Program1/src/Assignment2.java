import java.util.Scanner;
public class Assignment2 {

	public static void main(String[] args) {
		int temp,sum = 0, rem;
		//num = 454;
		Scanner add = new Scanner(System.in);
		int num = add.nextInt();
		
		temp = num;
		while(num > 0)
		{
			rem = num%10;
			sum = (sum*10)+rem;
			num = num/10;
		}
		if (temp == sum)
		{
			System.out.println("Entered number is palendrome");
		}
		else
		{
			System.out.println("Entered number is not palendrome");
		}

	}

}
