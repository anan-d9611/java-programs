
public class classw {

	public static void main(String[] args) {
		Class Student
		{
		  //Constructor- a block of code 
		  // called at instance creation (Object)
		  // e.g student sc = new student(no org); 
		  // Types of construcctor 
			//1) Def // no orguments  
				//e.g student sc = new student(no org);
			// 2) Para // rugment/s
			// student sc = new student(01,"Avinash");
		// construction and initialization
		 def__init__(self, name="Unknown"):
			self.name= name;
		// print the name
		 def print_name(self)
		  S.o.p.("name: {self.name}")
		 
		student = student("MIT");
		student =
		student = student();

		student.print_name();
		}

	}

}
