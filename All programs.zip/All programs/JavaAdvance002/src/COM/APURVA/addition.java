package COM.APURVA;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addition {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					addition window = new addition();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public addition() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label1 = new JLabel("Rate of Interest");
		label1.setBounds(32, 21, 97, 13);
		frame.getContentPane().add(label1);
		
		textField = new JTextField();
		textField.setBounds(156, 18, 96, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Period (in Years)");
		lblNewLabel.setBounds(32, 61, 97, 19);
		frame.getContentPane().add(lblNewLabel);
		
		textField_1 = new JTextField();
		textField_1.setBounds(156, 61, 96, 19);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Simple Interest");
		lblNewLabel_1.setBounds(32, 122, 97, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField_2 = new JTextField();
		textField_2.setBackground(new Color(255, 255, 128));
		textField_2.setBounds(156, 119, 96, 19);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("Result");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double a,b,c,SI;
				
				a= Double.parseDouble(textField.getText());
				b= Double.parseDouble(textField_1.getText());
				c= Double.parseDouble(textField_2.getText());
				
				SI = (a*b*c)/100;
				
				Result.setText(String.format("%.2f", SI));
			}
		});
		btnNewButton.setBounds(118, 170, 85, 21);
		frame.getContentPane().add(btnNewButton);
	}
}
