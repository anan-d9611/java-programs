package tut2;
import java.util.Date;

//Base class LibraryItem
abstract class LibraryItem {
 private String title;
 private String author;
 private int publicationYear;
 private String genre;
 private boolean isCheckedOut;
 private Date dueDate;

 // Constructor to initialize library item properties
 public LibraryItem(String title, String author, int publicationYear, String genre) {
     this.title = title;
     this.author = author;
     this.publicationYear = publicationYear;
     this.genre = genre;
     this.isCheckedOut = false;
 }

 // Getter and Setter methods for encapsulation
 public String getTitle() {
     return title;
 }

 public void setTitle(String title) {
     this.title = title;
 }

 public String getAuthor() {
     return author;
 }

 public void setAuthor(String author) {
     this.author = author;
 }

 public int getPublicationYear() {
     return publicationYear;
 }

 public void setPublicationYear(int publicationYear) {
     this.publicationYear = publicationYear;
 }

 public String getGenre() {
     return genre;
 }

 public void setGenre(String genre) {
     this.genre = genre;
 }

 public boolean isCheckedOut() {
     return isCheckedOut;
 }

 public void setCheckedOut(boolean checkedOut) {
     isCheckedOut = checkedOut;
 }

 public Date getDueDate() {
     return dueDate;
 }

 public void setDueDate(Date dueDate) {
     this.dueDate = dueDate;
 }

 // Method to check out an item (mark it as checked out)
 public void checkOut(Date dueDate) {
     if (!isCheckedOut) {
         isCheckedOut = true;
         this.dueDate = dueDate;
         System.out.println(title + " has been checked out. Due date: " + dueDate);
     } else {
         System.out.println(title + " is already checked out.");
     }
 }

 // Method to return an item (mark it as returned)
 public void returnItem() {
     if (isCheckedOut) {
         isCheckedOut = false;
         System.out.println(title + " has been returned.");
     } else {
         System.out.println(title + " is not checked out.");
     }
 }

 // Abstract method to calculate late fees (to be implemented in subclasses)
 public abstract double calculateLateFees();
}

//Subclass Book extending LibraryItem
class Book extends LibraryItem {
 private String publisher;

 // Constructor for Book
 public Book(String title, String author, int publicationYear, String genre, String publisher) {
     super(title, author, publicationYear, genre);
     this.publisher = publisher;
 }

 // Getter and Setter for publisher
 public String getPublisher() {
     return publisher;
 }

 public void setPublisher(String publisher) {
     this.publisher = publisher;
 }

 // Overridden method to calculate late fees for Books (0.5 per day)
 @Override
 public double calculateLateFees() {
     if (isCheckedOut()) {
         long diff = new Date().getTime() - getDueDate().getTime();
         long daysLate = diff / (1000 * 60 * 60 * 24);
         return daysLate * 0.5;
     }
     return 0.0;
 }
}

//Subclass Magazine extending LibraryItem
class Magazine extends LibraryItem {
 private String issue;

 // Constructor for Magazine
 public Magazine(String title, String author, int publicationYear, String genre, String issue) {
     super(title, author, publicationYear, genre);
     this.issue = issue;
 }

 // Getter and Setter for issue
 public String getIssue() {
     return issue;
 }

 public void setIssue(String issue) {
     this.issue = issue;
 }

 // Overridden method to calculate late fees for Magazines (0.3 per day)
 @Override
 public double calculateLateFees() {
     if (isCheckedOut()) {
         long diff = new Date().getTime() - getDueDate().getTime();
         long daysLate = diff / (1000 * 60 * 60 * 24);
         return daysLate * 0.3;
     }
     return 0.0;
 }
}

//Subclass DVD extending LibraryItem
class DVD extends LibraryItem {
 private String director;

 // Constructor for DVD
 public DVD(String title, String author, int publicationYear, String genre, String director) {
     super(title, author, publicationYear, genre);
     this.director = director;
 }

 // Getter and Setter for director
 public String getDirector() {
     return director;
 }

 public void setDirector(String director) {
     this.director = director;
 }

 // Overridden method to calculate late fees for DVDs (1.0 per day)
 @Override
 public double calculateLateFees() {
     if (isCheckedOut()) {
         long diff = new Date().getTime() - getDueDate().getTime();
         long daysLate = diff / (1000 * 60 * 60 * 24);
         return daysLate * 1.0;
     }
     return 0.0;
 }
}

public class stan {
 public static void main(String[] args) {
     // Creating LibraryItem objects
     Book book = new Book("Java Programming", "James Gosling", 1995, "Technology", "Addison-Wesley");
     Magazine magazine = new Magazine("National Geographic", "Various", 2022, "Science", "April Issue");
     DVD dvd = new DVD("Inception", "Christopher Nolan", 2010, "Sci-Fi", "Christopher Nolan");

     // Setting a due date for checkout
     Date dueDate = new Date(System.currentTimeMillis() + (5 * 24 * 60 * 60 * 1000)); // 5 days from now

     // Checking out items
     book.checkOut(dueDate);
     magazine.checkOut(dueDate);
     dvd.checkOut(dueDate);

     // Calculating late fees for each item (assuming 7 days late)
     try {
         Thread.sleep(7000); // Simulate 7 seconds (7 days in real-world scenario)
     } catch (InterruptedException e) {
         e.printStackTrace();
     }

     System.out.println("Late fee for book: $" + book.calculateLateFees());
     System.out.println("Late fee for magazine: $" + magazine.calculateLateFees());
     System.out.println("Late fee for DVD: $" + dvd.calculateLateFees());

     // Returning items
     book.returnItem();
     magazine.returnItem();
     dvd.returnItem();
 }
}
