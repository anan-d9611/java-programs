package mvc.firstProject;

public class AnimalView {
	
	public void displayAnimal(String name,String species) {
		System.out.println("Animal "+ name + "("+ species +")");
	}
}
