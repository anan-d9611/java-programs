package mvc.firstProject;

public class AnimalController {
	private Animal model;
	private AnimalView view;
	
	public AnimalController (Animal model, AnimalView view) {
		
		this.model = model;
		this.view = view;
	}
	
	public void setAnimalName(String name) {
		model.setName(name);
	}
	
	public void updateView() {
		view.displayAnimal(model.getName(),model.getSpecies());
	}

}
