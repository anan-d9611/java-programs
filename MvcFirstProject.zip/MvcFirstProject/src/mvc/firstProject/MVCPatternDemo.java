package mvc.firstProject;

public class MVCPatternDemo {

	public static void main(String[] args) {
		// Create model
		Animal model = new Animal("Leo","Lion");
		
		//Create View
		AnimalView view = new AnimalView();
		
		//CreateController
		AnimalController controller = new AnimalController(model,view);

		//first op
		controller.updateView();
		
		//Change Data
		controller.setAnimalName("Simba");
		
		//updated op
		controller.updateView();
	}

}
